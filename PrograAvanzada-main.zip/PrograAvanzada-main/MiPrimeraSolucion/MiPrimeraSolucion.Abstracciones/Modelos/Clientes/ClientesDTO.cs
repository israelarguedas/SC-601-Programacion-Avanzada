﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiPrimeraSolucion.Abstracciones.Modelos.Clientes
{
    public class ClientesDTO
    {
        public int Id { get; set; }
        [Display(Name = "Identificación")]
        [MinLength(9)]
        [Required]
        public string Identificación { get; set; }
        [Display(Name = "Nombre")]
        [MinLength(3)]
        [Required]
        public string Nombre { get; set; }
        [Display(Name = "Primer Apellido")]
        [MinLength(3)]
        [Required]
        public string PrimerApellido { get; set; }
        [Display(Name = "Segundo Apellido")]
        [MinLength(3)]
        [Required]
        public string SegundoApellido { get; set; }
        [Display(Name = "Teléfono")]
        [MinLength(8)]
        [Required]
        public string Telefono { get; set; }
        [Display(Name = "Correo electronico")]
        [MinLength(10)]
        [Required]
        public string Correo { get; set; }
        [Display(Name = "Fecha De Registro")]
        public DateTime FechaDeRegistro { get; set; }
        [Display(Name = "Fecha De Modificación")]
        public DateTime FechaDeModificacion { get; set; }
        [Display(Name = "Estado")]
        public bool Estado { get; set; }
    }
}
