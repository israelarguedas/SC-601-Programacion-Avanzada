﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiPrimeraSolucion.Abstracciones.Modelos.Inventario
{
    public class InventarioDTO
    {
        public int Id { get; set; }
        [Display(Name = "Código del repuesto")]
        [MinLength(4)]
        [Required]
        public string CodigoDelRepuesto { get; set; }
        [Display(Name = "Nombre del repuesto")]
        [MinLength(3)]
        [Required]
        public string NombreDelRepuesto { get; set; }
        [Display(Name = "Marca del repuesto")]
        [MinLength(3)]
        [Required]
        public string MarcaDelRepuesto { get; set; }
        [Display(Name = "Vehículo")]
        [MinLength(3)]
        [Required]
        public string Vehiculo { get; set; }
        [Display(Name = "Módelo")]
        [MinLength(3)]
        [Required]
        public string Modelo { get; set; }
        [Display(Name = "Año")]
        [MinLength(4)]
        [Required]
        public int Anio { get; set; }
        [Display(Name = "Cantidad")]
        [MinLength(1)]
        [Required]
        public int Cantidad { get; set; }
        [Display(Name = "Fecha de Registro")]
        public DateTime FechaDeRegistro { get; set; }
        [Display(Name = "Fecha de Modificación")]
        public DateTime FechaDeModificacion { get; set; }
        [Display(Name = "Estado")]
        public bool Estado { get; set; }
    }
}
