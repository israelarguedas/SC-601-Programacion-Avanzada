﻿using MiPrimeraSolucion.Abstracciones.Modelos.Inventario;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiPrimeraSolucion.Abstracciones.LogicaDeNegocio.Inventario
{
    public interface IObtenerInventarioLN
    {
        List<InventarioDTO> Obtener();
    }
}
