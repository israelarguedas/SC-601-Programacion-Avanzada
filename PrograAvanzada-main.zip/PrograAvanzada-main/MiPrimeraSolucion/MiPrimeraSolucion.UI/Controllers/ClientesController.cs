﻿using MiPrimeraSolucion.Abstracciones.Modelos.Clientes;
using MiPrimeraSolucion.Abstracciones.Modelos.Inventario;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MiPrimeraSolucion.UI.Controllers
{
    public class ClientesController : Controller
    {
        // GET: Clientes
        public ActionResult ObtenerClientes()
        {
            List<ClientesDTO> laListaClientes = new List<ClientesDTO>();
            laListaClientes.Add(new ClientesDTO
            {
                Id = 1,
                Identificación = "118810325",
                Nombre = "Carmila",
                PrimerApellido = "Fallas",
                SegundoApellido = "Cedeño",
                Telefono = "88859632",
                Correo = "carm.ced@correo.com",
                FechaDeRegistro = DateTime.Now.AddMonths(-2),
                FechaDeModificacion = DateTime.Now.AddDays(-10),
                Estado = true
            });
            laListaClientes.Add(new ClientesDTO
            {
                Id = 2,
                Identificación = "116610325",
                Nombre = "Alfonso",
                PrimerApellido = "Martinez",
                SegundoApellido = "Perez",
                Telefono = "88857412",
                Correo = "Alf.mart@correo.com",
                FechaDeRegistro = DateTime.Now.AddMonths(-2),
                FechaDeModificacion = DateTime.Now.AddDays(-10),
                Estado = true
            });

            return View(laListaClientes);
        }

        // GET: Clientes/Details/5
        public ActionResult DetallesClientes(int id)
        {
            return View(new ClientesDTO());
        }

        // GET: Clientes/Create
        public ActionResult AgregarClientes()
        {
            return View(new ClientesDTO());
        }

        // POST: Clientes/Create
        [HttpPost]
        public ActionResult AgregarClientes(ClientesDTO model)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("ObtenerClientes");
            }
            catch
            {
                return View();
            }
        }

        // GET: Clientes/Edit/5
        public ActionResult EditarClientes(int id)
        {
            return View(new ClientesDTO());
        }

        // POST: Clientes/Edit/5
        [HttpPost]
        public ActionResult EditarClientes(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("ObtenerClientes");
            }
            catch
            {
                return View();
            }
        }

        // GET: Clientes/Delete/5
        public ActionResult BorrarClientes(int id)
        {
            return View(new ClientesDTO());
        }

        // POST: Clientes/Delete/5
        [HttpPost]
        public ActionResult BorrarClientes(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("ObtenerClientes");
            }
            catch
            {
                return View();
            }
        }
    }
}
