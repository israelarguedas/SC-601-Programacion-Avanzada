﻿using MiPrimeraSolucion.Abstracciones.LogicaDeNegocio.Inventario;
using MiPrimeraSolucion.Abstracciones.Modelos.Inventario;
using MiPrimeraSolucion.LogicaDeNegocio.Inventario.ObtenerInventario;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MiPrimeraSolucion.UI.Controllers
{
    public class InventarioController : Controller
    {
        private IObtenerInventarioLN _obtenerInventarioLN;

        public InventarioController()
        {
            _obtenerInventarioLN = new ObtenerInventarioLN();
        }
        // GET: Inventario
        public ActionResult ObtenerInventario()
        {
            List<InventarioDTO> laListaDelInventario = _obtenerInventarioLN.Obtener();

            return View(laListaDelInventario);
        }

        // GET: Inventario/Details/5
        public ActionResult DetallesRepuesto(int id)
        {
            return View(new InventarioDTO());
        }

        // GET: Inventario/Create
        public ActionResult AgregarRepuesto()
        {
            return View(new InventarioDTO());
        }

        // POST: Inventario/Create
        [HttpPost]
        public ActionResult AgregarRepuesto(InventarioDTO ElRepuestoParaAgregar)
        {
            try
            {
                // TODO: Add create logic here

                return RedirectToAction("ObtenerInventario");
            }
            catch
            {
                return View();
            }
        }

        // GET: Inventario/Edit/5
        public ActionResult EditarRepuesto(int Id)
        {
            return View(new InventarioDTO());
        }

        // POST: Inventario/Edit/5
        [HttpPost]
        public ActionResult EditarRepuesto(int Id, FormCollection ElRepuestoParaEditar)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("ObtenerInventario");
            }
            catch
            {
                return View();
            }
        }

        // GET: Inventario/Delete/5
        public ActionResult BorrarRepuesto(int Id)
        {
            return View(new InventarioDTO());
        }

        // POST: Inventario/Delete/5
        [HttpPost]
        public ActionResult BorrarRepuesto(int Id, FormCollection ElRepuestoParaEliminar)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("ObtenerInventario");
            }
            catch
            {
                return View();
            }
        }
    }
}
