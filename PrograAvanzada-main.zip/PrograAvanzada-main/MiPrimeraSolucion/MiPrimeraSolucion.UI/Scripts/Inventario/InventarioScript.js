let table = new DataTable('#tablaDelInvetario');

$(document).ready(function () {
    $('#alertaSimple').click(function () {
        alert("Esta es una alerta simple.");
    });

    $('#alertaSweet').click(function () {
        Swal.fire({
            title: "Good job!",
            text: "You clicked the button!",
            icon: "success"
        });
    });


});