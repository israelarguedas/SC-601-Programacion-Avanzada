﻿using MiPrimeraSolucion.Abstracciones.Modelos.Inventario;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MiPrimeraSolucion.Abstracciones.LogicaDeNegocio.Inventario;
using System.Runtime.Remoting.Messaging;

namespace MiPrimeraSolucion.LogicaDeNegocio.Inventario.ObtenerInventario
{
    public class ObtenerInventarioLN : IObtenerInventarioLN
    {
        public List<InventarioDTO> Obtener() 
        {
            List<InventarioDTO> laListaDelInventario = new List<InventarioDTO>();
            laListaDelInventario.Add(new InventarioDTO
            {
                Id = 1,
                CodigoDelRepuesto = "REP001",
                NombreDelRepuesto = "Filtro de Aceite",
                MarcaDelRepuesto = "MarcaA",
                Vehiculo = "Toyota",
                Modelo = "Corolla",
                Anio = 2020,
                Cantidad = 50,
                FechaDeRegistro = DateTime.Now.AddMonths(-2),
                FechaDeModificacion = DateTime.Now.AddDays(-10),
                Estado = true
            });

            laListaDelInventario.Add(new InventarioDTO
            {
                Id = 2,
                CodigoDelRepuesto = "REP002",
                NombreDelRepuesto = "Filtro de Aceite",
                MarcaDelRepuesto = "MarcaA",
                Vehiculo = "Nissan",
                Modelo = "Kicks",
                Anio = 2020,
                Cantidad = 50,
                FechaDeRegistro = DateTime.Now.AddMonths(-2),
                FechaDeModificacion = DateTime.Now.AddDays(-10),
                Estado = true
            });

            return laListaDelInventario;
        }

    }
}
